/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package QueryProcessor;

public class Attribute{

   public  String name;
    public String datatype;
    public String size;

    public Attribute(String[] attr)
    {
    this.name = attr[0];
   this.datatype = attr[1]; 
  
   
    }

}
