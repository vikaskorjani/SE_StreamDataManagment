package QueryProcessor;

import java.io.BufferedWriter;
import java.io.File ;
import java.io.InputStream ;
import java.io.FileNotFoundException ;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ParameterMetaData;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;


import java.util.Calendar;
import org.apache.derby.impl.sql.execute.CurrentDatetime;
import java.sql.Timestamp;


public class Dbclass 
{
    public String[][] rowAndColumn;
    
    public String[] header;// build the GUI
		//TableWithModel twm = new TableWithModel(rowAndColumn, header);
    public Dbclass()
    {
   
		
    
    
    }
private static Connection con = null ;	
      
    private static final String driver = "org.apache.derby.jdbc.EmbeddedDriver" ;
    private static final String url = "jdbc:derby:memory:test;create=true" ;
    String SchemaName;
         /*String insertInfoSQL = 
        "INSERT INTO Student VALUES (?, ?, ?, ?, ?, ?)" ;
    */
/*         String selectInfoSQL =
                 "SELECT * FROM Student";
  */       
         public int createConnection()
    {
     try {
            Class.forName(driver);
            con = DriverManager.getConnection(url);
           
            SQLWarning swarn = con.getWarnings() ;

            if(swarn != null){
                printSQLWarning(swarn) ;
            }
    }
     catch(SQLException ex)
     {
         System.out.println("Sql exception");
         return 0;
     }
     catch(ClassNotFoundException ex)
     {
         System.out.println("Class not found exception");
         return 0;
     
     }
    return 1;
    }
    
    public int createTable(String createTableSql)
    {
        try
        {
     Statement stmt = con.createStatement() ;
            int counts = stmt.executeUpdate(createTableSql) ;
            con.commit() ;
        }
        catch(SQLException sq)
        {
             sq.printStackTrace();
       
        System.out.println("Some Sql Exception");
        return 0;
        }
        
    return 1;
    }
    
    public int dropTable(String dropTableSql)
    {
        try
        {
            Statement stmt = con.createStatement() ;
            int counts = stmt.executeUpdate(dropTableSql) ;
            con.commit() ;
        }
        catch(SQLException sq)
        {
             sq.printStackTrace();
       
        System.out.println("Some Sql Exception");
        return 0;
        }
        
        
        
    return 1;
    }
public int deleteTuple(String dropTableSql)
{int counts=0;
try
        {
            Statement stmt = con.createStatement() ;
            counts = stmt.executeUpdate(dropTableSql) ;
           
            con.commit() ;
        
        }
        catch(SQLException sq)
        {
             sq.printStackTrace();
       
        System.out.println("Some Sql Exception");
        
        }
        
        
        
    return counts;

}
    public String readTable(String selectInfoSQL,String schemaname)
    {
        
    
     int id = -1 ;
      int no_of_col;       
        int numRows = 0 ;
        String schemaName;
        BufferedWriter out=null;
        String ret_str = " ";
  try{
     FileWriter fstream = new FileWriter(schemaname + "output.txt",true);
     out = new BufferedWriter(fstream);
  //out.write(data);
  //Close the output stream
 
  }
  catch (Exception e){//Catch exception if any
  System.err.println("Error: " + e.getMessage());
  }
        String line = "------------------------------------" ;
try{
        SQLWarning swarn = null ;
        
        Statement stmt = con.createStatement() ;
        ResultSet rs = stmt.executeQuery(selectInfoSQL) ;
   
        
        //System.out.println("RESULT SET in String form********\n"+rs.toString());
        
        
        
        ResultSetMetaData rsmd = rs.getMetaData() ;
        
            no_of_col = rsmd.getColumnCount();
            ArrayList attr_array=new ArrayList();
            String[] attributes = new String[no_of_col];
            String[] attributestype = new String[no_of_col];
            System.out.println("\n");
            out.write("\n");
   	   int p = 1;
            while(p < no_of_col)
            {   
                attr_array.add(rsmd.getColumnName(p));
               // header[p-1]=rsmd.getColumnName(p);
                System.out.printf("%-30s|", rsmd.getColumnName(p)) ;
                
                out.write(rsmd.getColumnName(p)+"|");
            p++;
            }
           // header[p-1]=rsmd.getColumnName(p);
            attr_array.add(rsmd.getColumnName(p));
               
            System.out.printf("%-20s\n", rsmd.getColumnName(p)) ;
                out.write(rsmd.getColumnName(p)+"|\n");
                 System.out.println(line);
        int i=0;
        int k=0;
    	while (rs.next()) {
         i=0;
                while(i<no_of_col)
                {
                attributes[i]=rs.getString(attr_array.get(i).toString());
               // rowAndColumn[0][i]=rs.getString(attr_array.get(i).toString());
                
                i++;
                 }
          
                        
                swarn = rs.getWarnings() ;

    		if(swarn != null){
    			printSQLWarning(swarn) ;
    		}else{
    			numRows ++ ;
                        k=0;
                 while(k<no_of_col)
                 {
    			  System.out.printf("%-30.50s|", attributes[k]) ;
                          
                       
                            if(attributes[k]!=null)
                //if(attributes[i]!=null)
                            {ret_str = ret_str + "  "+attributes[k];
                
                                out.write(attributes[k].toString()+" |");
                            }
                            k++;
                 };
                 System.out.println("\n");
                 out.write("\n");
                }
    	
             
    	}
rs.close();
 out.close();
}
        catch(SQLException ex)
        {
           ex.printStackTrace();
        }
         catch(Exception ex)
         {
         ex.printStackTrace();
         }
   return ret_str;
               
    }
    
    
    
    public String[] createAndInsertTable(String selectInfoSQL,String schemaname)
    {
        
    
     int id = -1 ;
      int no_of_col;       
        int numRows = 0 ;
        String schemaName;
        BufferedWriter out=null;
        String ret_str = " ";
        String attributes[]={" "};
  try{
     FileWriter fstream = new FileWriter(schemaname + "output.txt",true);
     out = new BufferedWriter(fstream);
  //out.write(data);
  //Close the output stream
 
  }
  catch (Exception e){//Catch exception if any
  System.err.println("Error: " + e.getMessage());
  }
        String line = "------------------------------------" ;
try{
        SQLWarning swarn = null ;
        
        Statement stmt = con.createStatement() ;
        ResultSet rs = stmt.executeQuery(selectInfoSQL) ;
   
        
        //System.out.println("RESULT SET in String form********\n"+rs.toString());
        
        
        
        ResultSetMetaData rsmd = rs.getMetaData() ;
        
            no_of_col = rsmd.getColumnCount();
            ArrayList attr_array=new ArrayList();
            attributes = new String[no_of_col];
            String[] attributestype = new String[no_of_col];
            header = new String[no_of_col];
            rowAndColumn=new String[no_of_col][2000];
            
            
            System.out.println("\n");
            out.write("\n");
   	   int p = 1;
           int h=0;
            while(p < no_of_col)
            {   
                attr_array.add(rsmd.getColumnName(p));
                header[h]=rsmd.getColumnName(p);
                System.out.printf("%-30s|", rsmd.getColumnName(p)) ;
                
                out.write(rsmd.getColumnName(p)+"|");
            p++;
            h++;
            }
            header[h]=rsmd.getColumnName(p);
            attr_array.add(rsmd.getColumnName(p));
               
            System.out.printf("%-20s\n", rsmd.getColumnName(p)) ;
                out.write(rsmd.getColumnName(p)+"|\n");
                 System.out.println(line);
        int i=0;
        int k=0;
    	while (rs.next()) {
         i=0;
                while(i<no_of_col)
                {
                attributes[i]=rs.getString(attr_array.get(i).toString());
               // rowAndColumn[0][i]=new String();
                rowAndColumn[0][i]=rs.getString(attr_array.get(i).toString());
                
                i++;
                 }
          
        
                 swarn = rs.getWarnings() ;
                
    		if(swarn != null){
    			printSQLWarning(swarn) ;
    		}else{
    			numRows ++ ;
                        k=0;
                 while(k<no_of_col)
                 {
    			  System.out.printf("%-30.50s|", attributes[k]) ;
                         
                            if(attributes[k]!=null)
                //if(attributes[i]!=null)
                            {ret_str = ret_str + "  "+attributes[k];
                
                                out.write(attributes[k].toString()+" |");
                            }
                            k++;
                 };
                 System.out.println("\n");
                 out.write("\n");
                }
    	
             
    	}
rs.close();
 out.close();
}
        catch(SQLException ex)
        {
           ex.printStackTrace();
        }
         catch(Exception ex)
         {
         ex.printStackTrace();
         }
   return attributes;
               
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    public int insertValues(String[] values,String insertInfoSQL,ArrayList<Attribute> atr)
    {
        
        int size = atr.size();
        int g;
       /* for(int i=0;i<6;i++)
        {
        System.out.println(values[i]);
        }*/
        try{
            g=0;
        //   System.out.println("number of column " + size );
            PreparedStatement pstmt = con.prepareStatement(insertInfoSQL) ;
         while(g<size-1)
         {
         if(atr.get(g).datatype.equals("VARCHAR"))
          {
       
              
         
              //System.out.println(values[g]+"inserted");
                     pstmt.setString(g+1,values[g]) ;
                     g++;
          }
         else if (atr.get(g).datatype == "INT")
                 {
           //           System.out.println(values[k]+"inserted");
             
                     if(values[g].equals(""))
          {pstmt.setInt(g+1,0); 
          g++;
          }
             else{
                        
         pstmt.setInt(g+1,Integer.parseInt(values[g]));
         g++;
         }
                 }
         
         else if(atr.get(g).datatype == "DECIMAL")
                      
         {
             // System.out.println(values[k]+"inserted");
             
         pstmt.setDouble(g+1,Double.parseDouble(values[g]));
         g++;
         }
         
         else if(atr.get(g).datatype.equals("DATE"))
         {
              //System.out.println(values[k]+"inserted");
                      
          pstmt.setString(g+1,values[g]) ;
                     g++;   
         }
         else if(atr.get(g).datatype.equals("DOUBLE"))
                      
         {
         //     System.out.println(values[k]+"inserted");
             if(values[g].equals(""))
          {pstmt.setDouble(g+1,0.00) ;
          g++;
          }
             else{
         pstmt.setDouble(g+1,Double.parseDouble(values[g]));
         g++;
         }}
         else
         { //System.out.println(values[k]+"inserted");
          //  System.out.println("value of g " + g);
          pstmt.setString(g+1,values[g]) ;
                     g++;   
                 
         }
          
          
                  
                  }
        Calendar calendar = Calendar.getInstance();
        java.util.Date now = calendar.getTime();
        java.sql.Timestamp currentTimestamp = new java.sql.Timestamp(now.getTime());
          
         pstmt.setTimestamp(g+1,currentTimestamp);
                  /*pstmt.setString(1,values[0]) ;
      //pstmt.setBinaryStream(2, "Hi checking ", bFileLength) ;
      //pstmt.setAsciiStream(3, tIn, tFileLength) ;
      pstmt.setString(2,values[1]);
      pstmt.setString(3,values[2]);    
      pstmt.setString(4,values[3]);    
       pstmt.setString(5,values[4]);    
       pstmt.setInt(6,Integer.parseInt(values[5]));*/
      int n =   pstmt.executeUpdate();
   // System.out.println(n + " updated")        ;
    /* Statement stmt = con.createStatement() ;
            int counts = stmt.executeUpdate(insertInfoSQL) ;
            con.commit() ;*/
            
        }
        catch(SQLException sq)
        {
        sq.printStackTrace();
            
        System.out.println("Some sql exception");
        }
    
    
    return 1;
    }
    
     static void printSQLWarning(SQLWarning sw) {
        while(sw != null) {

            System.out.print("SQLWarning: State=" + sw.getSQLState()) ;
            System.out.println(", Severity = " + sw.getErrorCode()) ;
            System.out.println(sw.getMessage()); 

            sw = sw.getNextWarning();
        }
    }
     
   
}
