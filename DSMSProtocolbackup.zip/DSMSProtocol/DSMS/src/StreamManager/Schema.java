package StreamManager;
import java.io.*;
import java.util.*;
import java.util.ArrayList;
import QueryProcessor.*;

public class Schema {

    String schemaName;
    ArrayList<Attribute> mainattrlist = new <Attribute>ArrayList();    
    ArrayList<Attribute> tempattrlist = new <Attribute>ArrayList();    
    
    int no_of_attr;
   
    public String getSchemaName()
    {
    return schemaName;
    
    }
   public void printAttribute()
   {
   for (Attribute atr : mainattrlist)
   {
   System.out.println(atr.name + "," + atr.datatype);
   
   
   }
   
   }
   public ArrayList<Attribute> getmainAttributes()
   {
   return mainattrlist;
   }
  
    public ArrayList<Attribute> gettempAttributes()
   {
   return tempattrlist;
   }
  
    public String createSchemaQuery(String filename)
    {
        no_of_attr = 0;
            
        String CreateQuery="CREATE TABLE ";
        
        int j=0;    
  try{
        FileInputStream is=new FileInputStream("SchemaFiles/"+filename);
InputStreamReader ir=new InputStreamReader(is);
BufferedReader br=new BufferedReader(ir);
String line="";
schemaName = br.readLine();
//if(schemaName.equals(null))
   // System.out.println("no schema name exists" + schemaName);


String attr1 =br.readLine();
 String[] arr1= attr1.split(" ");
    Attribute attrobject1 = new Attribute(arr1);
    mainattrlist.add(attrobject1);
CreateQuery = CreateQuery + schemaName + "(";
CreateQuery=CreateQuery + attr1;
int l=0;
while((line=br.readLine())!=null)
{   
    String[] arr= line.split(" ");
    Attribute attrobject = new Attribute(arr);
    mainattrlist.add(attrobject);
               
    no_of_attr++;
    CreateQuery=CreateQuery + ","+line;
  }
CreateQuery = CreateQuery + ")";
System.out.println(CreateQuery);

  }
  catch(Exception ex)
  {     ex.printStackTrace();;
}
  //mainattrlist.clear();
   return CreateQuery;
    }
    
    
    public String createTempQuery(String filename)
    {
        no_of_attr=0;
     //   System.out.printf("temp function value of no_of_attr:"+no_of_attr);
        String CreateQuery="CREATE TABLE ";
        
        int j=0;    
  try{
        FileInputStream is=new FileInputStream("SchemaFiles/"+filename);
InputStreamReader ir=new InputStreamReader(is);
BufferedReader br=new BufferedReader(ir);
String line="";
schemaName = br.readLine();
String attr1 =br.readLine();
 String[] arr1= attr1.split(" ");
    Attribute attrobject1 = new Attribute(arr1);
    tempattrlist.add(attrobject1);
CreateQuery = CreateQuery + schemaName + "Temp" + "(";
CreateQuery=CreateQuery + attr1;
int l=0;
while((line=br.readLine())!=null)
{   
    String[] arr= line.split(" ");
    Attribute attrobject = new Attribute(arr);
    tempattrlist.add(attrobject);
               
    no_of_attr++;
    CreateQuery=CreateQuery + ","+line;
  }
CreateQuery = CreateQuery + ")";
System.out.println(CreateQuery);

  }
  catch(Exception ex)
  {     ex.printStackTrace();;
}
  //tempattrlist.clear();
   return CreateQuery;
    }
    
    
    public String dropTableQuery()
    {
    return "DROP TABLE " + schemaName;
    }
    
    
    public String dropTempTableQuery()
    {
    return "DROP TABLE " + schemaName+"Temp";
    }
    public String selectTableQuery()
    {
    return "SELECT * FROM " + schemaName;
    }
    public String selectTempTableQuery()
    {
    return "SELECT * FROM " + schemaName+"Temp";
    }
   public String createInsertQuery()
   {
      // System.out.println("Number of attribute" + no_of_attr);
       String InsertQuery="INSERT INTO "+ schemaName +" VALUES (";
       int count = no_of_attr;
       while(count>0)
       {
       
       InsertQuery=InsertQuery + "?,"; 
       count--;
       }
       
              InsertQuery=InsertQuery + "?)"; 
              System.out.println(InsertQuery);
              
    return InsertQuery;   
   }

 public String createTempInsert()
   {
       //System.out.println("Number of attribute" + no_of_attr);
       String InsertQuery="INSERT INTO "+schemaName+ "Temp" +" VALUES (";
       int count = no_of_attr;
       while(count>0)
       {
       
       InsertQuery=InsertQuery + "?,"; 
       count--;
       }
       
              InsertQuery=InsertQuery + "?)"; 
              System.out.println(InsertQuery);
              
    return InsertQuery;   
   }
public String deleteTupleQuery(int velocity)
{
    
 System.out.println("Velocity is :" + velocity);
    String sql = "delete from " + schemaName + " where id in (SELECT id FROM "+ schemaName +  " FETCH FIRST "+ velocity + " ROWS ONLY)";
//String sql = "delete from "+schemaName + " where TIMESTAMP = (select min(timestamp) from "+ schemaName+")";
return sql;

}
}
