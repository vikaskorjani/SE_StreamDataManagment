
package ServerCommunicationManager;

import java.net.*; 
import java.io.*; 
import java.util.ArrayList;
import QueryProcessor.*;
import StreamManager.*;
import dsms.*;

public class Server {
        String SchemaName;
    public static void main(String[] args) 
    {

        
                Dbclass db =new Dbclass();
   int connection = db.createConnection();
   if(connection == 1)
       System.out.println("Connection Succesfull");
   else
       System.out.println("Connection Unsuccesfull");


        try
		{
		ServerSocket ss = new ServerSocket(23);
		int ch;
		System.out.println("This is Server");
		while(true)
		{
		Socket s = ss.accept();
                System.out.println(s.getInetAddress());
		new NewClient(s,db);
		}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
    }
    }

class NewClient extends Thread
{
public static Socket s;
Dbclass db1;
String host;
String schemafile;
int no_of_query;
int no_of_aggquery;
int window_size;
String QueryFile;
String AggQueryFile;
int flag=0;
String seperator;
int velocity;
ArrayList<Attribute> atr1 = new ArrayList<Attribute>();
ArrayList<Attribute> atr2 = new ArrayList<Attribute>();
TableWithModel twm;
    BufferedReader in=null;
    PrintWriter pw=null;
    
NewClient(Socket s,Dbclass db)
	{
		this.s =s;
                this.db1=db;
                 
    
                start();
                
	}

public void run()
{
    
    int request;
    String filename;           
    
        try
		{
		 
		 in = new BufferedReader(new InputStreamReader(s.getInputStream()));
                 pw = new PrintWriter(s.getOutputStream(),true);
		
                     
                 while(true)
                 {
                 String str=null;
                 
                     while(str==null)
                     {
                     
                  str=in.readLine();
                     }
                  System.out.println(str);
                 request = Integer.parseInt(str);
                 System.out.println(request + "request recieved");
                 pw.println("Request Recieved");
                 switch(request)
                 {
                     case 0 : disconnect();
                                break;
                     case 1 : register();
                                break;
                     case 2 : receiveMetaDataFile(); 
                                break;
                     case 3 : receiveFilterQueryFile();    
                                break;
                     case 4 : receiveAggQueryFile();
                                break;
                     case 5 : receiveStream();
                                break;
                 
                 
                 }
                 
                 }
                }
        catch(Exception ex)
        {
ex.printStackTrace();
System.out.append("Connection Error");
            
            
        }
        
      

}
public void disconnect()
      {
      try{
         System.out.println("call");
      pw.println("disconnect request received");
     // String str=in.readLine();
      in.close();
       System.out.println("call2");
      s.close();
      }
      catch(Exception ex)
      {
      System.out.println("connection closed");
      }
      
      
      
      }

public void receiveMetaDataFile()
{/*
byte[] aByte = new byte[1];
        int bytesRead;
ByteArrayOutputStream baos = new ByteArrayOutputStream();
if (in != null) {

            FileOutputStream fos = null;
            BufferedOutputStream bos = null;
            try {
                fos = new FileOutputStream("C:/Users/vikas korjani/Documents/JavaProject/DSMS/SchemaFiles");
                bos = new BufferedOutputStream(fos);
                bytesRead = in.read(aByte, 0, aByte.length);

                do {
                        baos.write(aByte);
                        bytesRead = is.read(aByte);
                } while (bytesRead != -1);

                bos.write(baos.toByteArray());
                bos.flush();
                bos.close();
                //clientSocket.close();
            } catch (IOException ex) {
                // Do exception handling
            }
        }*/
    
    
    String filepath = "SchemaFiles/";
    String filename=null;
    try
    {
filename =in.readLine();
pw.println("server ready");
    System.out.print("in receive file"+filename);
    
FileReceive.receiveFile(s,filename,filepath);
System.out.println("filr received");
    }
    catch(Exception ex)
    {
    ex.printStackTrace();    
    }
    
    }


public void receiveFilterQueryFile()
{



String filepath = "FilterQueries/";

    String filename=null;
    try
    {
filename =in.readLine();
pw.println("server ready");
    System.out.print("in receive file"+filename);
    
FileReceive.receiveFile(s,filename,filepath);
    }
    catch(Exception ex)
    {
    ex.printStackTrace();    
    }
// FileReceive.receiveFile(s,filename,);
}


public void receiveAggQueryFile()
{


String filepath = "AggregateQueries/";

    String filename=null;
    try
    {
filename =in.readLine();
pw.println("server ready");
    System.out.print("in receive file"+filename);
    
FileReceive.receiveFile(s,filename,filepath);
    }
    catch(Exception ex)
    {
    ex.printStackTrace();    
    }
// FileReceive.receiveFile(s,filename,);

}

       public String getSchemaName(String Id) throws FileNotFoundException
    {
        try{
     BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream("Register1.txt")));
		
    // System.out.println("In schemaname function");
		System.out.println(Id);
		String str=br.readLine();
             //   System.out.println(str);
		while(str!=null)
		{
                   String[] detail = str.split(" ");
                   if(detail[0].equals(Id))
                    {
                        window_size=Integer.parseInt(detail[4]);
                        QueryFile=detail[3];
                        if(detail[5]!=null)
                        AggQueryFile=detail[5];
                        System.out.println("My seperator is " + detail[6]);
                        if(!detail[6].equals("null"))
                        seperator = detail[6];
                        else
                            seperator = " ";
                        System.out.println("window_size"+window_size);
                          velocity = Integer.parseInt(detail[7]);
                        
                        return detail[1];
                    
                    }
                   System.out.println(detail[0]+"-"+detail[1]);
                    str=br.readLine();
               }
		br.close();
		
                                 }catch(Exception e){e.printStackTrace();
                                 }                                            
                               // System.out.println("Going out of schema function");              

        return null;
    
    }
    
 
public void receiveStream()
{

           //host = s.getInetAddress().toString();
                Schema sc = new Schema();
                String schemaname;
                String temp=" ";
               // schemafile = getSchemaFile(host);
                int count;
                int no_tuple=0;
                try
		{
		String str;
		
                schemafile = getSchemaName(in.readLine());
               // System.out.println("read from registration file schema name " + schemafile);
                pw.println(schemafile.toUpperCase());
                        
           //     System.out.println("*************in while loop \n"+schemafile);
                String createTableSQL = sc.createSchemaQuery(schemafile);
               schemaname = sc.getSchemaName();
               
            //   System.out.println("From run + *"+ schemaname);
                String createTempSQL = sc.createTempQuery(schemafile);
                
                String insertValues = sc.createInsertQuery();
                
                String insertTempValues = sc.createTempInsert();
                
                String MaindropTableSQL = sc.dropTableQuery() ;
                String TempdropTableSQL = sc.dropTempTableQuery(); 
                  
                String deleteTupleSQL = sc.deleteTupleQuery(velocity);
                String selectSQL = sc.selectTableQuery();
                String selectTempSQL=sc.selectTempTableQuery();
               
                ArrayList contquery=null;
                if(!QueryFile.equals("null"))
                {System.out.println(QueryFile);
                    contquery=getContQuery();
                }
                
                ArrayList Aggquery=null;
                if(!AggQueryFile.equals("null"))
                {
                    System.out.println(AggQueryFile);
                 
                    Aggquery=getAggQuery();
               
                }
                atr1 =  sc.getmainAttributes();
                atr2= sc.gettempAttributes();
                sc.printAttribute();
                
                int tablecreated = db1.createTable(createTableSQL);
                if(tablecreated == 1)
                System.out.println("table created Succesfull");
                else
                System.out.println("table created Unsuccesfull");

                
                while(true)
		{

                    temp=" ";
                                    int temptablecreated = db1.createTable(createTempSQL);
                if(temptablecreated == 1)
                System.out.println("temp table created Succesfull");
                else
                System.out.println("temp table created Unsuccesfull");

                    str = in.readLine();
                        //System.out.println("*************in while loop \n"+str);
                    System.out.println(str);    
                    String[] items=str.split("\\"+seperator);
                   System.out.println("My sepertor is " + seperator);
                        
                 //    String[] items=str.split("\\|");
                     /*       
                int z=0;
                       for(String item : items)
                        {System.out.println (z+item);
                        z++;
                        }*/
                   // System.out.println("Xii th percentage:"+items[17]+"specified"+null+"");
                    if (str.equals("99999"))
				break;
		    
                    count = no_of_aggquery;
                    
                    db1.insertValues(items,insertValues,atr1);
                        db1.insertValues(items, insertTempValues, atr2);
                    
                    
                        
                    if(no_tuple>=window_size)
                        {
                           
                    
                            
                            if(flag==0)
                            {   db1.createAndInsertTable(selectTempSQL, schemaname);
                                twm = new TableWithModel(db1.rowAndColumn, db1.header);
                                flag=1;
                            }
                            String temparray[] = db1.createAndInsertTable(selectTempSQL, schemaname);
                            String newstring = temparray[0];
                            for(int g=1;g<temparray.length;g++)
                               newstring = newstring +"|"+ temparray[g];
                             
                            twm.takeInput(newstring,twm);
                            int tuple = db1.deleteTuple(deleteTupleSQL);
                                no_tuple=no_tuple-tuple;
                 
                            
                            
                            
                            if(!AggQueryFile.equals("null"))
                                    {
                                while(count >= 0)
                        {temp = temp + "$";
                        String t=" ";
                        t=db1.readTable(Aggquery.get(count).toString(),schemaname);
                      if(t!=" ")
                      { // outputStringToClient(t);    
                        
                          temp = temp + t;//db1.readTable(contquery.get(count).toString(),schemaname);
                      }else
                          temp = temp  + " ";
                           
                       count--;
                        }}
                                //               System.out.println("number of tuple: "+no_tuple);
                        }
                        
                          
                        count = no_of_query;
                        if(!QueryFile.equals("null"))
                        {    while(count >= 0)
                        {temp = temp + "$";
                        String t=" ";
                        t=db1.readTable(contquery.get(count).toString(),schemaname);
                      if(t!=" ")
                      { // outputStringToClient(t);    
                        
                          temp = temp + t;//db1.readTable(contquery.get(count).toString(),schemaname);
                      }else
                          temp = temp  + " ";
                           
                       count--;
                        }}
                          
     int temptabledropped = db1.dropTable(TempdropTableSQL);
  if(temptabledropped == 1)
       System.out.println("drop temp table Succesfull");
   else
       System.out.println("drop temp table Unsuccesfull");
                              
			System.out.println(str);
                        pw.println(temp.toUpperCase());
                       /* if(temp!=" ")
                            pw.write(temp);
                        else
                            pw.write(" ");*/
                            //                            outputStringToClient(temp);    
                        no_tuple++;
		}
                 db1.readTable(selectSQL,schemaname);                     
                   in.close();
		s.close();
             outputtoclient(schemaname);
 	
   //System.out.println(message); 
       // mySocket.close( ); 
   
     int tabledropped = db1.dropTable(MaindropTableSQL);
  if(tabledropped == 1)
       System.out.println("drop table Succesfull");
   else
       System.out.println("drop table Unsuccesfull");

     
	}
catch(Exception e)
{
System.out.println(e);
e.printStackTrace();
}


    
    
    
    
}




	public ArrayList getContQuery()
        {
        //String[] query={" "};
       ArrayList querylist = new ArrayList();
            no_of_query = -1;
        try
        {
           FileInputStream is=new FileInputStream("FilterQueries/"+QueryFile);
            InputStreamReader ir=new InputStreamReader(is);
            BufferedReader br=new BufferedReader(ir);
            String line="";
                while ((line=br.readLine())!=null)
                {
               querylist.add(line);
              // System.out.println(querylist.get(no_of_query)); 
               no_of_query++;
                }
        }
        catch(Exception ex)
        {
        ex.printStackTrace();
        }
        
        return querylist;
        }
        

        public ArrayList getAggQuery()
        {
        //String[] query={" "};
       ArrayList querylist = new ArrayList();
            no_of_aggquery = -1;
        try
        {
           FileInputStream is=new FileInputStream("AggregateQueries/"+AggQueryFile);
            InputStreamReader ir=new InputStreamReader(is);
            BufferedReader br=new BufferedReader(ir);
            String line="";
                while ((line=br.readLine())!=null)
                {
               querylist.add(line);
              // System.out.println(querylist.get(no_of_query)); 
               no_of_aggquery++;
                }
        }
        catch(Exception ex)
        {
        ex.printStackTrace();
        }
        
        return querylist;
        }
	

public void register()
{
BufferedWriter out;
    try{
String registerstring = in.readLine();
System.out.println(registerstring);

            FileWriter fstream = new FileWriter("Register1.txt",true);
            out = new BufferedWriter(fstream);
          System.out.println();
            out.write(registerstring+"\n");
            out.close();
    }
    catch(Exception ex)
    {
    ex.printStackTrace();
    }


}


    

public void outputtoclient(String schemaname)
{
   File file=null;
                                try 
                           {     Socket s = new Socket("192.16.11.171",2222);
                                   try{
                                   file = new File(schemaname+"output.txt");
                                   }
                                    catch(Exception e)
                                {System.out.println("file not found");
                                }
    BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
		PrintWriter pw = new PrintWriter(s.getOutputStream(),true);
		
	//	BufferedReader myin = new BufferedReader(new InputStreamReader(s.getInputStream()));
	//	System.out.println("This is Output from Client");
		String str=br.readLine();
                System.out.println(str);
		while(str!=null)
		{
               System.out.println(str);
		
                    //str = br.readLine();
			pw.println(str);
			//		str = myin.readLine();
			System.out.println(str);
                                                   str = br.readLine();
		}
		br.close();
		pw.close();
		s.close();

                                 }catch(Exception e){e.printStackTrace();
                                                                       }                       
	}
}







