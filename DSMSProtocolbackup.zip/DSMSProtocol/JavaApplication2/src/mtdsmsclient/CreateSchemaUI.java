package mtdsmsclient;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.Socket;

public class CreateSchemaUI extends JFrame implements ActionListener
{
    String parent;
    JLabel colnamel;
    JLabel typel;
    JLabel sizel;
    JLabel schemanamel;
    JTextField colnametf;
    JComboBox typecb;
    JTextField sizetf;
    JTextField schemanametf;
    JButton addColb;
    Register r;
//JButton done;
 int flag=0;

    

 BufferedWriter out =null;

public CreateSchemaUI(String parent)
{
    this.parent=parent;
    setTitle("Register Schema");
    String typeList[] = {"INTEGER", "DOUBLE", "VARCHAR", "DATE"};
    
    
    this.setSize(760,650);
    this.setTitle("Create Schema");
   

    Container panel=this.getContentPane();
    panel.setLayout(null);

    schemanamel=new JLabel("Schema Name");
    schemanamel.setSize(200,30);
    schemanamel.setLocation(10,10);
    panel.add(schemanamel);


        schemanametf=new JTextField();
       schemanametf.setSize(200,30);
       schemanametf.setLocation(250,10);
       panel.add(schemanametf);




    colnamel= new JLabel("Column Name");
    colnamel.setSize(200,30);
    colnamel.setLocation(10,50);
    panel.add(colnamel);

    colnametf=new JTextField();
       colnametf.setSize(200,30);
       colnametf.setLocation(250,50);
       panel.add(colnametf);


    typel= new JLabel("Type");
    typel.setSize(200,30);
   typel.setLocation(10,90);
    panel.add(typel);


         typecb = new JComboBox(typeList);
       typecb.setSize(200,30);
       typecb.setLocation(250,90);
       panel.add(typecb);



    sizel= new JLabel("Size");
    sizel.setSize(200,30);
    sizel.setLocation(10,130);
    panel.add(sizel);


       sizetf=new JTextField();
       sizetf.setSize(200,30);
       sizetf.setLocation(250,130);
       panel.add(sizetf);



       JButton newfield=new JButton("Add New Field");
       newfield.setSize(150,30);
       newfield.setLocation(260,190);
       newfield.addActionListener(new AddColumn());
       panel.add(newfield);

              JButton done=new JButton("Done");
       done.setSize(150,30);
       done.setLocation(260,230);
       done.addActionListener(this);
       panel.add(done);

setSize(700,700);
 setVisible(true);

}





public void actionPerformed(ActionEvent ac)
{


System.out.println("Done clicked");
String schemaname =  schemanametf.getText();
String colname = colnametf.getText();
String type = typecb.getSelectedItem().toString();
String size = sizetf.getText();

try{
if(flag==0)

{ 
    //File f=new File("schemas\\"+schemaname+"metadata.txt");
    FileWriter fstream = new FileWriter("schemas\\"+schemaname+"metadata.txt",true);
            out = new    BufferedWriter(fstream);
            System.out.print("file created");
out.write(schemaname+"\n");
flag=1;
}
out.write(colname + "(" + size + ")\n");

out.close();

File f =  new File("schemas\\"+schemaname+"metadata.txt");
System.out.println(serverRequestType("File Send"));

MTDSMSClient.pw.println("2");
String resp = MTDSMSClient.myin.readLine();
System.out.println(resp);
MTDSMSClient.pw.println(f.getName());
resp = MTDSMSClient.myin.readLine();
System.out.println(resp);
System.out.println("sumit");
sendfile(f);
this.dispose();
if(parent.equals("Registration"))
new Register();




}
catch(Exception ex)
{
ex.printStackTrace();
}

}
public int serverRequestType(String str)
{
if(str.equals("File Send"))
     return 2;
else 
    return 0;

}

  public void sendfile(File file){

  BufferedOutputStream outToClient = null;

  
        try{
        outToClient = new BufferedOutputStream(MTDSMSClient.s.getOutputStream());
        }catch(Exception e){}

        byte[] mybytearray = new byte[(int) file.length()];

        FileInputStream fis = null;


                try {
                    fis = new FileInputStream(file);
                } catch (FileNotFoundException ex) {
                    // Do exception handling
                }
                BufferedInputStream bis = new BufferedInputStream(fis);

                    try {
                    bis.read(mybytearray, 0, mybytearray.length);
                    outToClient.write(mybytearray, 0, mybytearray.length);
                    outToClient.flush();
                    outToClient.close();
               

                    // File sent, exit the main method
                    return;
                } catch (IOException ex) {
                    ex.printStackTrace();
                    // Do exception handling
                }



  }





 class AddColumn implements ActionListener
{

     public void actionPerformed(ActionEvent ac)
{
String schemaname =  schemanametf.getText();
String colname = colnametf.getText();
String type = typecb.getSelectedItem().toString();
String size = sizetf.getText();

try{
if(flag==0)
{ // File f=new File("schemas\\"+schemaname+"metadata.txt");
    FileWriter fstream = new FileWriter("schemas\\"+schemaname+"metadata.txt",true);
            out = new    BufferedWriter(fstream);
out.write(schemaname+"\n");
flag=1;
}
out.write(colname + "(" + size + ")\n");

colnametf.setText("");
sizetf.setText("");
System.out.println("1 col added");
schemanametf.disable();
}
catch(Exception ex)
{
ex.printStackTrace();
}





}


}


}

