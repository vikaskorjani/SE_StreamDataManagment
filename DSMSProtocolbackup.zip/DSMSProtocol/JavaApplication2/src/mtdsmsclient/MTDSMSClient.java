package mtdsmsclient;

import java.awt.image.*;
import java.io.*;
import java.net.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.imageio.ImageIO;
import java.util.*;




public class  MTDSMSClient extends JFrame implements ActionListener
{

   Image img=null;
   File schemafile;
   File cqueryfile;
   File aqueryfile;
   String registration;

   JLabel emp1=new JLabel("");
   JLabel emp2=new JLabel("");
   JLabel emp3=new JLabel("");
   JLabel emp4=new JLabel("");
   JLabel emp5=new JLabel("");
   JLabel emp6=new JLabel("");
   JLabel emp7=new JLabel("");
   JLabel emp8=new JLabel("");
   JLabel emp9=new JLabel("");
   JLabel emp10=new JLabel("");
   JLabel emp11=new JLabel("");

   public static BufferedReader myin;
   public static BufferedReader br;
   public static PrintWriter pw;
   public static Socket s;

    JPanel jp1=new JPanel();
    JPanel jp2=new JPanel();
    JPanel jp3=new JPanel();
    JPanel jp4=new JPanel();
   JLabel label1=new JLabel("Connect to");
   JTextField text1=new JTextField();


    JLabel label2=new JLabel("Port");
  
   JTextField text2=new JTextField();


   JButton connect=new JButton("Connect");
   JButton register=new JButton("Register Stream");


   //JButton sendregistraion=new JButton("SendREgistration");
   JButton createschema=new JButton("Register Schema");
   JButton createquery=new JButton("Register  query ");


   JButton disconnect=new JButton("Diconnect");
   JButton sendstream= new JButton("Send Stream");
    ArrayList<String> streamfiles= new ArrayList<String>();
    JComboBox jcb;
      JLabel label3=new JLabel("Select Stream");
    JPanel jp=new JPanel();

    ArrayList<String> getstreamList()
     {
          ArrayList<String> list=new ArrayList<String>();


       File folder = new File("stream");
       File[] listOfFiles = folder.listFiles();

      for (int i = 0; i < listOfFiles.length; i++) {
      if (listOfFiles[i].isFile()) {
          System.out.println(listOfFiles[i].getName());
        list.add(listOfFiles[i].getName());
      }
    }



         return list;
     }


  public MTDSMSClient()
      {
      setSize(600,600);
      setTitle("DSMS Client");
      label1.setFont(new Font("Comic Sans MS", Font.PLAIN, 14));
      label2.setFont(new Font("Comic Sans MS", Font.PLAIN, 14));
      label3.setFont(new Font("Comic Sans MS", Font.PLAIN, 14));
      streamfiles= getstreamList();
       jcb=new JComboBox(streamfiles.toArray());

       jp.setLayout(new GridLayout(2,1,20,20));


jp1.setLayout(null);




label1.setSize(150,30);
label1.setLocation(10,25);
jp1.add(label1);

text1.setSize(300,30);
text1.setLocation(200,25);
 jp1.add(text1);


 label2.setSize(150,30);
label2.setLocation(10,65);
jp1.add(label2);

text2.setSize(300,30);
text2.setLocation(200,65);
 jp1.add(text2);

connect.setSize(100,40);
connect.setLocation(200,105);
  jp1.add(connect);

  disconnect.setSize(100,40);
  disconnect.setLocation(310,105);
  jp1.add(disconnect);


  label3.setSize(150,30);
  label3.setLocation(10,170);
  jp1.add(label3);

jcb.setSize(150,40);
jcb.setLocation(200,170);
jp1.add(jcb);

  sendstream.setSize(100,40);
  sendstream.setLocation(370,170);
  jp1.add(sendstream);
 
  jp.add(jp1);


 jp2.setLayout(new GridLayout(1,2,20,20));
// jp2.setLayout(null);
 BufferedImage myPicture=null;
try{
 myPicture = ImageIO.read(new File("stream.jpg"));
}
catch(Exception e){System.out.println(e);}
JLabel picLabel = new JLabel(new ImageIcon( myPicture ));


jp3.add(picLabel);
jp2.add(jp3);

jp4.setLayout(null);



       register.setSize(150,30);
       register.setLocation(110,10);
       register.setFont(new Font("Comic Sans MS", Font.BOLD, 14));
       jp4.add(register);

       //jp4.add(emp8);

       createschema.setSize(150,30);
       createschema.setLocation(110,70);
      
       createschema.setFont(new Font("Comic Sans MS", Font.BOLD, 14));

       jp4.add(createschema);
     //  jp4.add(emp9);

       createquery.setSize(150,30);
       createquery.setLocation(110,130);
       
       createquery.setFont(new Font("Comic Sans MS", Font.BOLD, 14));

      jp4.add(createquery);
     // jp4.add(emp10);


      
     // jp4.add(emp11);
      register.addActionListener(this);
      disconnect.addActionListener(this);
      createquery.addActionListener(this);
      createschema.addActionListener(this);
       connect.addActionListener(this);
       sendstream.addActionListener(this);

      jp2.add(jp4);
      jp.add(jp2);

      add(jp);
      register.setEnabled(false);
      createquery.setEnabled(false);
      createschema.setEnabled(false);
      disconnect.setEnabled(false);
      sendstream.setEnabled(false);
      try
  {
   UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
   SwingUtilities.updateComponentTreeUI(getContentPane());
  }
  catch(Exception e)
  {
   System.exit(0);
  }
 setVisible(true);
     }

  public void sendfile(File file){

  BufferedOutputStream outToClient = null;
        try{
        outToClient = new BufferedOutputStream(s.getOutputStream());
        }catch(Exception e){}

        byte[] mybytearray = new byte[(int) file.length()];

        FileInputStream fis = null;


                try {
                    fis = new FileInputStream(file);
                } catch (FileNotFoundException ex) {
                    // Do exception handling
                }
                BufferedInputStream bis = new BufferedInputStream(fis);

                    try {
                    bis.read(mybytearray, 0, mybytearray.length);
                    outToClient.write(mybytearray, 0, mybytearray.length);
                    outToClient.flush();
                    outToClient.close();


                    // File sent, exit the main method
                    return;
                } catch (IOException ex) {
                    // Do exception handling
                }



  }
  public void actionPerformed(ActionEvent ae)
  {
      if(ae.getSource()==connect)
      {
          try{
           s = new Socket(text1.getText(),23);
           pw = new PrintWriter(s.getOutputStream(),true);
           myin = new BufferedReader(new InputStreamReader(s.getInputStream()));
          }catch(Exception e){System.out.println(e);}

            connect.setEnabled(false);
            register.setEnabled(true);
            createquery.setEnabled(true);
            createschema.setEnabled(true);
            disconnect.setEnabled(true);
            sendstream.setEnabled(true);
          }


      if(ae.getSource()==disconnect)
     {
       try{
       pw.println("0");
       String str=myin.readLine();
       System.out.println(str);
       br.close();
       pw.close();
      // s.close();
       }
       catch(Exception e){System.out.println("connection closed");}

        register.setEnabled(false);
      createquery.setEnabled(false);
      createschema.setEnabled(false);
      disconnect.setEnabled(false);
      sendstream.setEnabled(false);
      connect.setEnabled(true);
     }
      
    if(ae.getSource()==register)
     {
      Register r=new Register();
  }

       if(ae.getSource()==createquery)
       {
           QueryUI q=new QueryUI(this.getTitle());

       }
     
      if(ae.getSource()==createschema)
       {
          new CreateSchemaUI(this.getTitle());
         
       }
     
      if(ae.getSource()==sendstream)
     {
              
         String filename=(String)jcb.getSelectedItem();
              new SendDataStream(filename);
         
  }}}

class SendDataStream extends Thread
{String filename;
public SendDataStream(String fn)
{
filename = "stream/"+fn;
start();

}

public void run()
{


         String[][] rowAndColumn = {
				{"data1", "data2","data3","data4","data5",},
			};
		// defines the header
		String[] header = {"Colunm1", "Tuple Sent","Aggregate Query1","AggregateQuery2","ContinuousQuery1"};
		// build the GUI
		TableWithModel twm = new TableWithModel(rowAndColumn, header);



     
     File file=null;
                int count=0;
            BufferedWriter out =null;
                try{
                                   file = new File(filename);
                                   }
                                    catch(Exception e)
                                {System.out.println("file not found");
                                }
                        try{

                        MTDSMSClient.pw.println("5");
                        String resp = MTDSMSClient.myin.readLine();
                        System.out.println(resp);
//System.out.println(resp);

                BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
	            FileWriter fstream = new FileWriter("output.txt",true);
                out = new BufferedWriter(fstream);
		        System.out.println("This is Client");


                String str=br.readLine();


                while(str!=null)
		{
                    count++;
                System.out.println(str);
                String temp1;
                String temp2;
                    //str = br.readLine();
                        MTDSMSClient.pw.println(str);
			   if(str.equals("99999"))
				break;
                         temp1 = str;

                        str = MTDSMSClient.myin.readLine();
                       if(!str.equals(" $ ") && !str.equals(" $ $ ")&&!str.equals(" "))
                        { out.write(str);
                        temp2=temp1+"$"+str;
                        twm.takeInput(str,twm);

                        System.out.println(count + ").Server: "+str);
                        }
                str = br.readLine();
		}
                MTDSMSClient.br.close();
		MTDSMSClient.pw.close();

  

                                 }catch(Exception e){e.printStackTrace();
                                                                       }
	}


  }

































/*
public class MTDSMSClient extends JFrame implements ActionListener
{
    
   File SchemaFile;
   File AggQueryFile;
   File FilterQueryFile;
   String Registration;
          
   Socket sock;
   public static BufferedReader myin;
   BufferedReader br;
   public  static PrintWriter pw;
   
   JButton subscribe=new JButton("Subscribe");
   JButton disconnect=new JButton("Diconnect");
   
   JTextField filename = new JTextField();
   JButton SendStream = new JButton("Send Stream");
  JPanel jp=new JPanel();
   
  public MTDSMSClient(Socket s)
      {
      this.sock=s;


      try{
	 pw = new PrintWriter(Connect.s.getOutputStream(),true);

     myin = new BufferedReader(new InputStreamReader(Connect.s.getInputStream()));
      }
      catch(Exception e){System.out.println(e);}

      setSize(200,100);
      setVisible(true);
      jp.setLayout(new BorderLayout());

      subscribe.addActionListener(this);
      disconnect.addActionListener(this);
      SendStream.addActionListener(this);
      jp.add(subscribe,BorderLayout.NORTH);
      jp.add(disconnect,BorderLayout.CENTER);
      jp.add(filename,BorderLayout.CENTER);
      jp.add(SendStream,BorderLayout.SOUTH);

      add(jp);
      }

  public void sendfile(File file){

  BufferedOutputStream outToClient = null;
        try{
        outToClient = new BufferedOutputStream(sock.getOutputStream());
        }catch(Exception e){}

        byte[] mybytearray = new byte[(int) file.length()];

        FileInputStream fis = null;


                try {
                    fis = new FileInputStream(file);
                } catch (FileNotFoundException ex) {
                    // Do exception handling
                }
                BufferedInputStream bis = new BufferedInputStream(fis);

                    try {
                    bis.read(mybytearray, 0, mybytearray.length);
                    outToClient.write(mybytearray, 0, mybytearray.length);
                    outToClient.flush();
                    outToClient.close();
               

                    // File sent, exit the main method
                    return;
                } catch (IOException ex) {
                    ex.printStackTrace();
                    // Do exception handling
                }


 }*/
  
  /*
  public void actionPerformed(ActionEvent ae)
  {
     if(ae.getSource()==subscribe)
     {
         
          Register r=new Register(sock);
           



     }
     if(ae.getSource()==SendStream)
     {
              String[][] rowAndColumn = {
				{"data1", "data2","data3","data4","data5",},
			};
		// defines the header
		String[] header = {"Colunm1", "Tuple Sent","Aggregate Query1","AggregateQuery2","ContinuousQuery1"};
		// build the GUI
		TableWithModel twm = new TableWithModel(rowAndColumn, header);
		
          
         		
        /*       String[][] rowAndColumn = {
				{"data1", "data2","data3","data4","data5"},
			};
		// defines the header
		String[] header = {"Colunm1", "Tuple Sent","Aggregate Query1","AggregateQuery2","ContinuousQuery1"};
		// build the GUI
		TableWithModel twm = new TableWithModel(rowAndColumn, header);
                String token = "vikas $ is $ screwed";
                twm.takeInput(token, twm);
      
      /*   System.out.println("in SendStream");
     File file=null;
                int count=0;
            BufferedWriter out =null;    
            
                try{
                                   file = new File(filename.getText());
                                   }
                                    catch(Exception e)
                                {System.out.println("file not found");
                                }
                try{
                    
                         pw.println("5");
String resp = myin.readLine();
System.out.println(resp);
//System.out.println(resp);

    BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
	FileWriter fstream = new FileWriter("output.txt",true);
            out = new BufferedWriter(fstream);		
		System.out.println("This is Client");
	
                
                String str=br.readLine();
                
                
                while(str!=null)
		{
                    count++;
               System.out.println(str);
                String temp1;
                String temp2;
                    //str = br.readLine();
			pw.println(str);
			if(str.equals("99999"))
				break;
                         temp1 = str;
                        
                        str = myin.readLine();
                       if(!str.equals(" $ ") && !str.equals(" $ $ "))
                        { out.write(str);
                        temp2=temp1+"$"+str;
                        twm.takeInput(str,twm);
                
                        System.out.println(count + ").Server: "+str);
                        }
                str = br.readLine();
		}
		br.close();
		pw.close();
	        
                	ServerSocket ss = new ServerSocket(2222);
                            Socket s1 = ss.accept();
              		BufferedReader in = new BufferedReader(new InputStreamReader(s1.getInputStream()));
                            String line;
                        while(true)
                        {
                        line=in.readLine();
                         System.out.println(line);
                        if(line==null)
                            break;
                                   
                        
                        }
                
                
                
                                 }catch(Exception e){e.printStackTrace();
                                                                       }                     
	}     
     
     
     
     /*if(ae.getSource()==disconnect)
     {
         JFileChooser chooser = new JFileChooser();

         int returnVal = chooser.showOpenDialog(null);
         if(returnVal == JFileChooser.APPROVE_OPTION) {
         String name=chooser.getSelectedFile().getName();
         File file = chooser.getSelectedFile();
        String pathofstream =file.getAbsolutePath();
        jf3.setText(pathofstream);

          sendfile(file);
         
     }
     }
     if(ae.getSource()==regQuery)
     {
          JFileChooser chooser = new JFileChooser();

          int returnVal = chooser.showOpenDialog(null);
          if(returnVal == JFileChooser.APPROVE_OPTION) {
          String pathofquery=chooser.getSelectedFile().getName();
        File file = chooser.getSelectedFile();
      pathofquery=file.getAbsolutePath();
       // jf3.setText(pathofquery);


     }

     }
    if(ae.getSource()==reset)
      {
        //jf1.setText("");
        //jf2.setText("");
        //jf3.setText("");
      }
     if(ae.getSource()==stream)
     {}
      * 
     if(ae.getSource()==disconnect)
     {
       try{
     sock.close();
       }
       catch(Exception e){System.out.println(e);}
     }
}

/*
class SendStream implements ActionListener
{
public void actionPerformed(ActionEvent ae)
{
File file=null;
                int count=0;
            BufferedWriter out =null;    
            
                try{
                                   file = new File(filename.getText());
                                   }
                                    catch(Exception e)
                                {System.out.println("file not found");
                                }
                try{
                    
                         pw.println("5");
String resp = myin.readLine();
System.out.println(resp);

    BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
	FileWriter fstream = new FileWriter("output.txt",true);
            out = new BufferedWriter(fstream);		
		System.out.println("This is Client");
		String str=br.readLine();
                System.out.println(str);
		
               String[][] rowAndColumn = {
				{"data1", "data2","data3","data4","data5"},
			};
		// defines the header
		String[] header = {"Colunm1", "Tuple Sent","Aggregate Query1","AggregateQuery2","ContinuousQuery1"};
		// build the GUI
		TableWithModel twm = new TableWithModel(rowAndColumn, header);
		
                while(str!=null)
		{
                    count++;
               System.out.println(str);
                String temp1;
                String temp2;
                    //str = br.readLine();
			pw.println(str);
			if(str.equals("99999"))
				break;
                         temp1 = str;
                        
                        str = myin.readLine();
                        if(!str.equals(" $ ") && !str.equals(" $ $ "))
                        { out.write(str);
                        temp2=temp1+"$"+str;
                        twm.takeInput(temp2,twm);
                
                        System.out.println(count + ").Server: "+str);
                        }                          str = br.readLine();
		}
		br.close();
		pw.close();
	        
                	ServerSocket ss = new ServerSocket(2222);
                            Socket s1 = ss.accept();
              		BufferedReader in = new BufferedReader(new InputStreamReader(s1.getInputStream()));
                            String line;
                        while(true)
                        {
                        line=in.readLine();
                         System.out.println(line);
                        if(line==null)
                            break;
                                   
                        
                        }
                
                
                
                                 }catch(Exception e){e.printStackTrace();
                                                                       }                     
	




}
}*/
