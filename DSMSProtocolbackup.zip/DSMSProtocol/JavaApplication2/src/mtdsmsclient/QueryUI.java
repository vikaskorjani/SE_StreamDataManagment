/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package mtdsmsclient;

/**
 *
 * @author sumit
 */
import java.awt.Container;
import javax.swing.*;
import java.awt.event.*;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.BufferedReader;
import java.io.FileWriter;
import java.util.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class QueryUI extends JFrame implements ItemListener{
    String parent;
    ArrayList<String> schemafiles= new ArrayList<String>();
    DefaultListModel dlm = new DefaultListModel();
    JList lst;
    JScrollPane jsp;
    JComboBox jcb;
    JTextField schema_text = new JTextField();
    JTextArea query_text = new JTextArea();
    int flag;
   

    class ContinuousQueryHandler implements ActionListener {

     public void actionPerformed(ActionEvent e){

             try{
                    query_text.setEditable(true);
                    flag = 0;
     }catch (Exception ex){
            ex.printStackTrace();
     }
     }
 }

     class CloseHandler implements ActionListener {
         String parent;

         public CloseHandler(String parent)
         {
         this.parent=parent;
         }

     public void actionPerformed(ActionEvent e){

         if(parent.equals("Registration"))
         {
           Register r=new Register();
         }
         dispose();
     }
 }

      class AggregateQueryHandler implements ActionListener {

     public void actionPerformed(ActionEvent e){


          try{
                query_text.setEditable(true);
                flag = 1;
     }catch (Exception ex){
            ex.printStackTrace();
     }
     }
 }

      class SubmitHandler implements ActionListener {

     public void actionPerformed(ActionEvent e){
         String filename;
     String schema_name = jcb.getSelectedItem().toString();
     System.out.println(schema_name);
     String query_name = query_text.getText();
          try{
                if(flag==0)
                    
{   
    String[] name=schema_name.split("\\.");                
    
    filename = name[0]+"ContinuousQuery.txt";
    FileWriter fstream = new FileWriter("cqueries\\"+filename,false);
    BufferedWriter  out = new    BufferedWriter(fstream);
            out.write(query_name);
            System.out.println("File Created");

            
out.close();
File f =  new File("cqueries\\"+filename);
//System.out.println(serverRequestType("File Send"));

MTDSMSClient.pw.println("3");
String resp = MTDSMSClient.myin.readLine();
System.out.println(resp);
MTDSMSClient.pw.println(f.getName());
resp = MTDSMSClient.myin.readLine();
System.out.println(resp);
System.out.println("sumit");
sendfile(f);
}
                else{
    String[] name=schema_name.split("\\.");                
    filename = name[0]+"AggQuery.txt";
    FileWriter fstream = new FileWriter("aqueries\\"+filename,false);
    BufferedWriter  out = new    BufferedWriter(fstream);
            out.write(query_name);
            System.out.println("File Created");

            
out.close();
File f =  new File("aqueries\\"+filename);
//System.out.println(serverRequestType("File Send"));

MTDSMSClient.pw.println("4");
String resp = MTDSMSClient.myin.readLine();
System.out.println(resp);
MTDSMSClient.pw.println(f.getName());
resp = MTDSMSClient.myin.readLine();
System.out.println(resp);
System.out.println("sumit");
sendfile(f);
                }
//out.write(query_name);


query_text.setText("");
schema_text.setText("");
query_text.setEditable(false);
     }catch (Exception ex){
            ex.printStackTrace();
     }
     }
 }

       public void sendfile(File file){

  BufferedOutputStream outToClient = null;

  
        try{
        outToClient = new BufferedOutputStream(MTDSMSClient.s.getOutputStream());
        }catch(Exception e){}

        byte[] mybytearray = new byte[(int) file.length()];

        FileInputStream fis = null;


                try {
                    fis = new FileInputStream(file);
                } catch (FileNotFoundException ex) {
                    // Do exception handling
                }
                BufferedInputStream bis = new BufferedInputStream(fis);

                    try {
                    bis.read(mybytearray, 0, mybytearray.length);
                    outToClient.write(mybytearray, 0, mybytearray.length);
                    outToClient.flush();
                    outToClient.close();
               

                    // File sent, exit the main method
                    return;
                } catch (IOException ex) {
                    ex.printStackTrace();
                    // Do exception handling
                }



  }





      
public void itemStateChanged(ItemEvent e) {
String name=(String) e.getItem();
try
{
BufferedReader br=new BufferedReader(new FileReader("schemas\\"+name));
dlm.removeAllElements();
String str=null;
while ((str = br.readLine()) != null) {
System.out.println(str);
dlm.addElement(str);
}

}
catch(Exception ex){System.out.println(ex);}
}

QueryUI(String parent){
            this.setSize(800,750);
            this.parent=parent;

            this.setTitle("Query Registration");
           

             schemafiles=getschemaList();
             jcb=new JComboBox(schemafiles.toArray());

            JLabel schema_label = new JLabel();
            schema_label.setLocation(30,10);
            schema_label.setSize(150,30);
            schema_label.setText("Enter schema name : ");

            JLabel displayschema_label = new JLabel();
            displayschema_label.setLocation(30,70);
            displayschema_label.setSize(150,30);
            displayschema_label.setText("Schema Details : ");

            JLabel query_label = new JLabel();
            query_label.setLocation(30,275);
            query_label.setSize(400,30);
            query_label.setText("Select the type of query you would like to register : ");

            schema_text.setLocation(160,10);
            schema_text.setSize(515,30);

             jcb.setLocation(160,10);
            jcb.setSize(515,30);
            jcb.addItemListener(this);
            JButton cont_qry = new JButton();
            cont_qry.setLocation(30,325);
            cont_qry.setSize(300, 30);
            cont_qry.setText("Continuous Query");
            cont_qry.addActionListener(this.new ContinuousQueryHandler());

            JButton agg_qry = new JButton();
            agg_qry.setLocation(370,325);
            agg_qry.setSize(300, 30);
            agg_qry.setText("Aggregate Query");
            agg_qry.addActionListener(this.new AggregateQueryHandler());

            JButton submit = new JButton();
            submit.setLocation(300,625);
            submit.setSize(100, 30);
            submit.setText("Register");
            submit.addActionListener(this.new SubmitHandler());

              JButton close = new JButton();
            close.setLocation(420,625);
            close.setSize(100, 30);
            close.setText("Close");
            close.addActionListener(this.new CloseHandler(parent));


            JLabel list = new JLabel();
            list.setLocation(30,425);
            list.setSize(150,30);
            list.setText("Register Query here : ");

            query_text.setLocation(30,465);
            query_text.setSize(640,100);
            query_text.setEditable(false);

             lst = new JList(dlm);
            lst.setFixedCellWidth(100);
            lst.setVisibleRowCount(3);
            jsp = new JScrollPane(lst);
            jsp.setLocation(160,70);
            jsp.setSize(515,150);

            Container panel = this.getContentPane();

            panel.setLayout(null);

            panel.add(schema_label);
           // panel.add(schema_text);
            panel.add(jcb);
            panel.add(displayschema_label);
            panel.add(jsp);
            panel.add(query_label);
            panel.add(cont_qry);
            panel.add(agg_qry);
            panel.add(list);
            panel.add(query_text);
            panel.add(submit);
            panel.add(close);
            setVisible(true);
}


 ArrayList<String> getschemaList()
     {
        ArrayList<String> list=new ArrayList<String>();

       File folder = new File("schemas");
       File[] listOfFiles = folder.listFiles();

      for (int i = 0; i < listOfFiles.length; i++) {
      if (listOfFiles[i].isFile()) {
        list.add(listOfFiles[i].getName());
      }
    }


         return list;
     }

}