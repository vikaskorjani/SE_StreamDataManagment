/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mtdsmsclient;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.Font;
import java.awt.event.*;
import java.util.*;
import java.io.*;

public class Register extends JFrame implements ActionListener {

    
    ArrayList<String> streamfiles= new ArrayList<String>();
    ArrayList<String> schemafiles= new ArrayList<String>();
    ArrayList<String> aqueryfiles= new ArrayList<String>();
    ArrayList<String> cqueryfiles= new ArrayList<String>();

   

    JPanel jp1=new JPanel();
    JPanel jp2=new JPanel();
    JPanel jp3=new JPanel();
    JPanel jp4=new JPanel();
    JPanel jp5=new JPanel();
    JPanel jp6=new JPanel();
    JPanel jp7=new JPanel();
    JPanel jp8=new JPanel();
    JPanel jp9=new JPanel();
    JPanel jp10=new JPanel();
    JPanel jp11=new JPanel();

    JLabel label1=new JLabel(" IP");
    JTextField jf1=new JTextField();
    JLabel emp1=new JLabel("");



    JLabel label2=new JLabel(" Stream ID");
    JTextField jf2=new JTextField( );
     JLabel emp2=new JLabel("");

     
     JLabel label3=new JLabel(" Separator");
     JComboBox jcb1=new JComboBox();
     JLabel emp3=new JLabel("");
     
     JLabel label4=new JLabel(" Stream Name");
     JComboBox jcb2;
     JLabel emp4=new JLabel("");


    
     JLabel label5=new JLabel(" Schema File");
     JComboBox jcb3;
     JButton schema=new JButton("New Schema");

    
     JLabel label6=new JLabel(" Filter Query Name");
     JComboBox jcb4;
     JButton cquery=new JButton("New Query");



     JLabel label7=new JLabel(" Aggregate Qyery Name ");
     JComboBox jcb5;
     JButton aquery=new JButton("New Query");


     JLabel label8=new JLabel(" Window Size");
     JTextField jf3=new JTextField();
     JLabel emp5=new JLabel("");

    JLabel label9=new JLabel(" Window Velocity");
     JTextField jf4=new JTextField();
     JLabel emp6=new JLabel("");
     
     JButton submit=new JButton("Submit");
    public Register()
    {
     setTitle("Registration") ;
    
     setSize(600,500);
   
     
     /*submit.addActionListener(new ActionListener(){
     
     public void actionPerformed(ActionEvent ex)
     {
     String ip=jf1.getText(); 
     String streamid=jf2.getText();
     String seperator=jcb1.getSelectedItem().toString();         
     String streamfile=jcb2.getSelectedItem().toString();
     String schemaname= jcb3.getSelectedItem().toString();
     String contquery=jcb4.getSelectedItem().toString();
     String aggquery=jcb5.getSelectedItem().toString();
     String windowsize=jf3.getText();        
  try{           
     MTDSMSClient.pw.println("1");
String resp = MTDSMSClient.myin.readLine();
System.out.println(resp);
MTDSMSClient.pw.println(streamid  + " " + schemaname + " " + ip + " " + contquery + " "+windowsize+" "+aggquery);
  }
  catch(Exception e1)
  {
  e1.printStackTrace();
  }


     
     System.out.println("Stream Id : " + streamid  + "\n Schemafile :" + schemaname + "\n IP :" + ip + "\n Continous Query file" + contquery + "\n Window Size :"+windowsize+"\n Agg Query:"+aggquery);
     
    
     }
  
     });*/
             
             
             
             
 


   

     jcb1.addItem("null");
     jcb1.addItem("|");
     jcb1.addItem(",");
     jcb1.addItem("$");
     


     schemafiles=getschemaList();
     streamfiles= getstreamList();
     aqueryfiles=getaqueryList();
     cqueryfiles=getcqueryList();
     jcb2=new JComboBox(streamfiles.toArray());
     
     jcb3=new JComboBox(schemafiles.toArray());
     
     jcb4=new JComboBox(cqueryfiles.toArray());
     jcb5=new JComboBox(aqueryfiles.toArray());


     jp1.setLayout(new GridLayout(10, 3,20, 20));
     jp2.setLayout(new GridLayout(1,3,20,20));
     jp3.setLayout(new GridLayout(1,3,20,20));
     
     jp4.setLayout(new GridLayout(1,3,20,20));
     jp5.setLayout(new GridLayout(1,3,20,20));
     jp6.setLayout(new GridLayout(1,3,20,20));
     jp7.setLayout(new GridLayout(1,3,20,20));
     jp8.setLayout(new GridLayout(1,3,20,20));
     jp9.setLayout(new GridLayout(1,3,20,20));
     jp11.setLayout(new GridLayout(1,3,20,20));
     jp10.setLayout(new BorderLayout());
     jp10.setBorder(new LineBorder(Color.RED, 1, true));

     label1.setFont(new Font("Courier New", Font.BOLD, 12));
     label2.setFont(new Font("Courier New", Font.BOLD, 12));
     label3.setFont(new Font("Courier New", Font.BOLD, 12));
     label4.setFont(new Font("Courier New", Font.BOLD, 12));
     label5.setFont(new Font("Courier New", Font.BOLD, 12));
     label6.setFont(new Font("Courier New", Font.BOLD, 12));
     label7.setFont(new Font("Courier New", Font.BOLD, 12));
     label8.setFont(new Font("Courier New", Font.BOLD, 12));
     label9.setFont(new Font("Courier New", Font.BOLD, 12));

    jp2.add(label1);
    jp2.add(jf1) ;
    jp2.add(emp1);

    jp3.add(label2);
    jp3.add(jf2);
    jp3.add(emp2);

    jp4.add(label3);
    jp4.add(jcb1) ;
    jp4.add(emp3);

    

    jp5.add(label4);
    jp5.add(jcb2);
    jp5.add(emp4);

    jp6.add(label5);
    jp6.add(jcb3);
    jp6.add(schema);

    jp7.add(label6);
    jp7.add(jcb4);
    jp7.add(aquery);

    jp8.add(label7);
    jp8.add(jcb5);
    jp8.add(cquery);


    jp9.add(label8);
    jp9.add(jf3);
    jp9.add(emp5);

     jp11.add(label9);
     jp11.add(jf4);
     jp11.add(emp6);
    jp10.add(submit,BorderLayout.EAST);

    jp1.add(jp2);
    jp1.add(jp3);
    jp1.add(jp4);
    jp1.add(jp5);
    jp1.add(jp6);
    jp1.add(jp7);
    jp1.add(jp8);
    jp1.add(jp9);
    jp1.add(jp11);
    jp1.add(jp10);
   
    

     add(jp1);

          try
  {
   UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
   SwingUtilities.updateComponentTreeUI(getContentPane());
  }
  catch(Exception e)
  {
   System.exit(0);
  }

     schema.addActionListener(this);
      cquery.addActionListener(this);
       aquery.addActionListener(this);
     submit.addActionListener(this);
      setVisible(true);
    }
    public void actionPerformed(ActionEvent e)
    {

    if(e.getSource()==schema)
    {
        this.dispose();
        new  CreateSchemaUI(this.getTitle());
        

    }

     if(e.getSource()==cquery)
    {
        this.dispose();
       QueryUI q= new  QueryUI(this.getTitle());


    }


     if(e.getSource()==aquery)
    {
        this.dispose();
  QueryUI    q=   new  QueryUI(this.getTitle());


    }


   if(e.getSource()==submit)
   {
   String ip=jf1.getText(); 
     String streamid=jf2.getText();
     String seperator=jcb1.getSelectedItem().toString();         
     String streamfile=jcb2.getSelectedItem().toString();
     String schemaname= jcb3.getSelectedItem().toString();
     String contquery=jcb4.getSelectedItem().toString();
     String aggquery=jcb5.getSelectedItem().toString();
     String windowsize=jf3.getText();     
     String velocity = jf4.getText();
  try{           
     MTDSMSClient.pw.println("1");
String resp = MTDSMSClient.myin.readLine();
System.out.println(resp);
MTDSMSClient.pw.println(streamid  + " " + schemaname + " " + ip + " " + contquery + " "+windowsize+" "+aggquery+ " " + seperator+" "+velocity);
String registerstring = streamid  + " " + streamfile  +" " + schemaname + " " + ip + " " + contquery + " "+windowsize+" "+aggquery+ " " + seperator+" "+velocity;   
  
  BufferedWriter out;
    try{
//String registerstring = in.readLine();
System.out.println(registerstring);

            FileWriter fstream = new FileWriter("Register1.txt",true);
            out = new BufferedWriter(fstream);
          System.out.println();
            out.write(registerstring+"\n");
            out.close();
    }
    catch(Exception ex)
    {
    ex.printStackTrace();
    }



  
  
  }
  catch(Exception e1)
  {
  e1.printStackTrace();
  }


     
     System.out.println("Stream Id : " + streamid  + "\n Schemafile :" + schemaname + "\n IP :" + ip + "\n Continous Query file" + contquery + "\n Window Size :"+windowsize+"\n Agg Query:"+aggquery);
     
  this.dispose();
     
 

       
       
       
       
    }}

     ArrayList<String> getschemaList()
     {
        ArrayList<String> list=new ArrayList<String>();

       File folder = new File("schemas");
       File[] listOfFiles = folder.listFiles();

      for (int i = 0; i < listOfFiles.length; i++) {
      if (listOfFiles[i].isFile()) {
        list.add(listOfFiles[i].getName());
      }
    }


         return list;
     }

     ArrayList<String> getstreamList()
     {
          ArrayList<String> list=new ArrayList<String>();
        

       File folder = new File("stream");
       File[] listOfFiles = folder.listFiles();

      for (int i = 0; i < listOfFiles.length; i++) {
      if (listOfFiles[i].isFile()) {
        list.add(listOfFiles[i].getName());
      }
    }



         return list;
     }

     ArrayList<String> getaqueryList()
     {
          ArrayList<String> list=new ArrayList<String>();

          list.add("null");

       File folder = new File("aqueries");
       File[] listOfFiles = folder.listFiles();

      for (int i = 0; i < listOfFiles.length; i++) {
      if (listOfFiles[i].isFile()) {
        list.add(listOfFiles[i].getName());
      }
    }

         return list;
     }

 ArrayList<String> getcqueryList()
     {
          ArrayList<String> list=new ArrayList<String>();
          list.add("null");

       File folder = new File("cqueries");
       File[] listOfFiles = folder.listFiles();

      for (int i = 0; i < listOfFiles.length; i++) {
      if (listOfFiles[i].isFile()) {
        list.add(listOfFiles[i].getName());
      }
    }

         return list;
     }



}
